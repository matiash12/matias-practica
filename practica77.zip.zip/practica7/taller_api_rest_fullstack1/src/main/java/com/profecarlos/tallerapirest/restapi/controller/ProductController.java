package com.profecarlos.tallerapirest.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.profecarlos.tallerapirest.restapi.model.Product;
import com.profecarlos.tallerapirest.restapi.repository.InventoryRepository;
import com.profecarlos.tallerapirest.restapi.repository.ProductRepository;

@RestController
@RequestMapping("/api/v1")
public class ProductController {

    private final InventoryRepository inventoryRepository;

    @Autowired
    private ProductRepository productRepository;

    // Inyección del repositorio de inventario por constructor
    public ProductController(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }

    // Crear nuevo producto
    @PostMapping("product")
    public ResponseEntity<?> insertProduct(@RequestBody Product producto) {
        try {
        Product savedProduct = productRepository.save(producto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body("{\"message\": \"Producto creado exitosamente\", \"id\": " + savedProduct.getId() + "}");
        } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("{\"error\": \"Error al crear el producto\"}");
        }
}

    // Listar todos los productos
    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productRepository.findAll();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Obtener producto por ID
    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable("id") int id) {
        return productRepository.findById(id)
                .map(product -> new ResponseEntity<>(product, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Buscar productos por categoría
    @GetMapping("/products/categoria/{categoria}")
    public ResponseEntity<List<Product>> getProductsByCategoria(@PathVariable String categoria) {
        List<Product> products = productRepository.findByCategoria(categoria);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    // Actualizar producto existente
   @PutMapping("product/{id}")
    public ResponseEntity<?> updateProduct(@PathVariable("id") int id, @RequestBody Product productoActualizado) {
        return productRepository.findById(id)
                .map(productoExistente -> {
                    productoExistente.setNombre(productoActualizado.getNombre());
                    productoExistente.setCategoria(productoActualizado.getCategoria());
                    productoExistente.setPrecio(productoActualizado.getPrecio());
                    productoExistente.setDescripcion(productoActualizado.getDescripcion());
                    productRepository.save(productoExistente);
                    return ResponseEntity.ok("{\"message\": \"Producto actualizado correctamente\"}");
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("{\"error\": \"Producto no encontrado\"}"));
}

    // Eliminar producto y su inventario asociado
    @DeleteMapping("product/{id}")
        public ResponseEntity<?> deleteProduct(@PathVariable("id") int id) {
            return productRepository.findById(id)
                    .map(producto -> {
                        inventoryRepository.findByIdProducto(id).ifPresent(inventoryRepository::delete);
                        productRepository.delete(producto);
                        return ResponseEntity.ok("{\"message\": \"Producto y su inventario eliminados\"}");
                    })
                    .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body("{\"error\": \"Producto no encontrado\"}"));
        }
}
