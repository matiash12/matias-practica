package com.profecarlos.tallerapirest.restapi.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.profecarlos.tallerapirest.restapi.model.Inventario;
import com.profecarlos.tallerapirest.restapi.model.InventarioProductoDTO;
import com.profecarlos.tallerapirest.restapi.model.Product;
import com.profecarlos.tallerapirest.restapi.repository.InventoryRepository;
import com.profecarlos.tallerapirest.restapi.repository.ProductRepository;

@RestController
@RequestMapping("/api/v1")
public class InventoryProductController {
    
   @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InventoryRepository inventarioRepository;

  @PostMapping("/producto-con-inventario")
public ResponseEntity<?> crearProductoConInventario(@RequestBody InventarioProductoDTO dto) {
    try {
        // Crear producto
        Product producto = new Product();
        producto.setNombre(dto.getNombre());
        producto.setCategoria(dto.getCategoria());
        producto.setPrecio(dto.getPrecio());
        producto.setDescripcion(dto.getDescripcion());
        Product productoGuardado = productRepository.save(producto);

        // Crear inventario asociado al producto
        Inventario inventario = new Inventario();
        inventario.setIdProducto(productoGuardado.getId());
        inventario.setStockActual(dto.getStockActual());
        inventario.setStockMinimo(dto.getStockMinimo());
        Inventario inventarioGuardado = inventarioRepository.save(inventario);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Producto e inventario creados exitosamente");
        response.put("producto", productoGuardado);
        response.put("inventario", inventarioGuardado);

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    } catch (Exception e) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Error al crear producto e inventario: " + e.getMessage());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

@GetMapping("/inventario-detallado")
public ResponseEntity<?> listarInventarioDetallado() {
    try {
        List<Inventario> inventarios = inventarioRepository.findAll();

        List<InventarioProductoDTO> listaDTO = inventarios.stream()
            .map(inv -> {
                return productRepository.findById(inv.getIdProducto())
                    .map(prod -> {
                        InventarioProductoDTO dto = new InventarioProductoDTO();
                        dto.setNombre(prod.getNombre());
                        dto.setCategoria(prod.getCategoria());
                        dto.setPrecio(prod.getPrecio());
                        dto.setDescripcion(prod.getDescripcion());
                        dto.setStockActual(inv.getStockActual());
                        dto.setStockMinimo(inv.getStockMinimo());
                        return dto;
                    })
                    .orElse(null);
            })
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        return ResponseEntity.ok(listaDTO);
    } catch (Exception e) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Error al listar inventario detallado: " + e.getMessage());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

}

