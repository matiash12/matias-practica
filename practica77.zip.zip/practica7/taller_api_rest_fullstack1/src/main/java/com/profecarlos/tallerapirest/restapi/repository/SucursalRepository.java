package com.profecarlos.tallerapirest.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.profecarlos.tallerapirest.restapi.model.Sucursal;;

public interface SucursalRepository extends JpaRepository<Sucursal, Integer> {

    
}
