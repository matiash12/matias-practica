package com.profecarlos.tallerapirest.restapi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.profecarlos.tallerapirest.restapi.model.Inventario;

/**
 * Repositorio para acceder a datos del inventario.
 * Extiende JpaRepository para operaciones CRUD automáticas.
 */
public interface InventoryRepository extends JpaRepository<Inventario, Integer> {

    /**
     * Busca el primer inventario asociado a un producto por su ID.
     * Útil si se espera solo un inventario por producto.
     */
    Optional<Inventario> findFirstByIdProducto(int idProducto);

    /**
     * Busca un inventario por ID de producto.
     * Alternativa simple si solo se maneja un inventario por producto.
     */
    Optional<Inventario> findByIdProducto(int idProducto);
}
   

    

