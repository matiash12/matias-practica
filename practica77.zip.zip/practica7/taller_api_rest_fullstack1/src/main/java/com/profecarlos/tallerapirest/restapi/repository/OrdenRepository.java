package com.profecarlos.tallerapirest.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.profecarlos.tallerapirest.restapi.model.Orden;

public interface OrdenRepository extends JpaRepository<Orden, Integer> {
}

