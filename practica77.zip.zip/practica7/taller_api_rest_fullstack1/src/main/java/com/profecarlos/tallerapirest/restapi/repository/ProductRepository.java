package com.profecarlos.tallerapirest.restapi.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.profecarlos.tallerapirest.restapi.model.Product;

/**
 * Repositorio para acceder a datos de productos.
 * Proporciona operaciones CRUD y consultas personalizadas.
 */
public interface ProductRepository extends JpaRepository<Product, Integer> {

    /**
     * Busca todos los productos que pertenezcan a una categoría específica.
     */
    List<Product> findByCategoria(String categoria);
}




