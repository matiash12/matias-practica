package com.profecarlos.tallerapirest.restapi.controller;

import java.util.List;
//import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import com.profecarlos.tallerapirest.restapi.model.Sucursal;
import com.profecarlos.tallerapirest.restapi.repository.SucursalRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;




@RestController
@RequestMapping("/api/v1")
public class SucursalController {

    @Autowired
    private SucursalRepository sucursalRepository;

    @PostMapping("sucursal")
    public ResponseEntity<Sucursal> insertSucursal(@RequestBody Sucursal sucursal){
        Sucursal saved = sucursalRepository.save(sucursal);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping("sucursales")
    public ResponseEntity<List<Sucursal>> getAllSucursales(){
        List<Sucursal> lista = sucursalRepository.findAll();
        return new ResponseEntity<>(lista, HttpStatus.OK);
    }

    @GetMapping("sucursal/{id}")
    public ResponseEntity<Sucursal> getSucursalById(@PathVariable("id") int id){
        return sucursalRepository.findById(id)
                .map(s -> new ResponseEntity<>(s, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("sucursal/{id}")
    public ResponseEntity<Sucursal> updateSucursal(@PathVariable("id") int id, @RequestBody Sucursal sucursalNueva) {
        return sucursalRepository.findById(id)
                .map(sucursal -> {
                    sucursal.setNombre(sucursalNueva.getNombre());
                    sucursal.setDireccion(sucursalNueva.getDireccion());
                    Sucursal updated = sucursalRepository.save(sucursal);
                    return new ResponseEntity<>(updated, HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("sucursal/{id}")
    public ResponseEntity<Void> deleteSucursal(@PathVariable("id") int id) {
        return sucursalRepository.findById(id)
                .map(sucursal ->{
                    sucursalRepository.delete(sucursal);
                    return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
                })
                .orElse(new ResponseEntity<Void>(HttpStatus.NOT_FOUND));
    }  
}
