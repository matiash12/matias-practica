package com.profecarlos.tallerapirest.restapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.*;

import com.profecarlos.tallerapirest.restapi.model.Orden;
import com.profecarlos.tallerapirest.restapi.repository.OrdenRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;




@RestController
@RequestMapping("/api/v1")
public class OrdenController {

    @Autowired
    private OrdenRepository ordenRepository;

    @PostMapping("orden")
    public ResponseEntity<Orden> insertOrden(@RequestBody Orden orden) {
        Orden saved = ordenRepository.save(orden);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping("ordenes")
    public ResponseEntity<List<Orden>> getAllOrdenes(){
        List<Orden> lista = ordenRepository.findAll();
        return new ResponseEntity<>(lista, HttpStatus.OK);
    }

    @GetMapping("orden/{id}")
    public  ResponseEntity<Orden> getOrdenById(@PathVariable("id") int id) {
        return ordenRepository.findById(id)
                .map(o -> new ResponseEntity<>(o, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("orden/{id}")
    public ResponseEntity<Orden> updateOrden(@PathVariable("id") int id, @RequestBody Orden ordenActualizada) {
        return ordenRepository.findById(id)
                .map(orden -> {
                    orden.setDescripcion(ordenActualizada.getDescripcion());
                    orden.setFecha(ordenActualizada.getFecha());
                    orden.setEstado(ordenActualizada.getEstado());
                    Orden updated = ordenRepository.save(orden);
                    return new ResponseEntity<>(updated, HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("orden/{id}")
    public ResponseEntity<Void> deleteOrden(@PathVariable("id") int id) {
        return ordenRepository.findById(id)
            .map(orden -> {
                ordenRepository.delete(orden);
                return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
            })
            .orElse(new ResponseEntity<Void>(HttpStatus.NOT_FOUND));
    }

    

    
}









