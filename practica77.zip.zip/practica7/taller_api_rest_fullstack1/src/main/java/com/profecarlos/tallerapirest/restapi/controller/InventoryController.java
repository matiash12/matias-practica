package com.profecarlos.tallerapirest.restapi.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.profecarlos.tallerapirest.restapi.model.Inventario;
import com.profecarlos.tallerapirest.restapi.repository.InventoryRepository;

@RestController
@RequestMapping("/api/v1")
public class InventoryController {

    @Autowired
    private InventoryRepository inventarioRepository;

    // Crear un nuevo inventario
    @PostMapping("/inventory")
        public ResponseEntity<Inventario> insertInventory(@RequestBody Inventario inventario) {
            try {
                Inventario saved = inventarioRepository.save(inventario);
                System.out.println("✅ Inventario creado con ID: " + saved.getId());
                return new ResponseEntity<>(saved, HttpStatus.CREATED);
            } catch (Exception e) {
                System.err.println("❌ Error al guardar inventario: " + e.getMessage());
                return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
            }
}

     @GetMapping("/inventory")
    public ResponseEntity<?> getAllInventory() {
        try {
            List<Inventario> inventory = inventarioRepository.findAll();
            return new ResponseEntity<>(inventory, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Error al obtener el inventario");
            return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

@GetMapping("/inventory/{id}")
public ResponseEntity<?> getInventoryById(@PathVariable("id") int id) {
    Optional<Inventario> inventarioOpt = inventarioRepository.findById(id);

    if (inventarioOpt.isPresent()) {
        return ResponseEntity.ok(inventarioOpt.get());
    } else {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Inventario no encontrado con ID: " + id);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }
}

@PutMapping("/inventory/{id}")
public ResponseEntity<?> updateInventory(
        @PathVariable("id") int id,
        @RequestBody Inventario inventarioActualizado) {

    Optional<Inventario> inventarioOpt = inventarioRepository.findById(id);

    if (inventarioOpt.isPresent()) {
        Inventario inventarioExistente = inventarioOpt.get();
        inventarioExistente.setStockActual(inventarioActualizado.getStockActual());
        inventarioExistente.setStockMinimo(inventarioActualizado.getStockMinimo());
        Inventario actualizado = inventarioRepository.save(inventarioExistente);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Inventario actualizado exitosamente");
        response.put("inventario", actualizado);

        return ResponseEntity.ok(response);
    } else {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Inventario no encontrado con ID: " + id);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
    }
}

}


    

    
    
